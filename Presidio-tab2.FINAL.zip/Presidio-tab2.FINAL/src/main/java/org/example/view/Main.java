package org.example.view;


public class Main {
    public static void main(String[] args) throws Exception {
            CellsValidator  validator = new CellsValidator();
            validator.alocarPrisioneiro();
        }
    }

