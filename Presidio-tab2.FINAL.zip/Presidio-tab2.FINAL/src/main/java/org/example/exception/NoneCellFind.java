package org.example.exception;

public class NoneCellFind extends RuntimeException {
    public NoneCellFind(String message) {
        super(message);
    }
}
