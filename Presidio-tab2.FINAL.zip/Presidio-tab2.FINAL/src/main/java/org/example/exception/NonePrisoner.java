package org.example.exception;

public class NonePrisoner extends RuntimeException {
    public NonePrisoner(String message) {
        super(message);
    }
}
