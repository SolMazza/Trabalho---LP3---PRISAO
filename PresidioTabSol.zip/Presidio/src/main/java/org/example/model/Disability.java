package org.example.model;

public enum Disability {
    SIM, NAO
}