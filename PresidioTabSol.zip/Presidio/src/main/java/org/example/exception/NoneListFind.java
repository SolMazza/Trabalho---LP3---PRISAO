package org.example.exception;

public class NoneListFind extends RuntimeException {
    public NoneListFind(String message) {
        super(message);
    }
}
