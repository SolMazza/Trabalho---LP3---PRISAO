package org.example;

public enum FaccaoLeader {
    SIM, NAO
}
