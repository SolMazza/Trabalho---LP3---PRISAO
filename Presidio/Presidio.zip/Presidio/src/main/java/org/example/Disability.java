package org.example;

public enum Disability {
    SIM, NAO
}